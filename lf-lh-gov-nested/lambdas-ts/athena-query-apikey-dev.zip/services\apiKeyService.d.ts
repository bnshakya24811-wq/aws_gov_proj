export declare class ApiKeyService {
    private client;
    private tableName;
    private logger;
    constructor(region: string, tableName: string);
    /**
     * Look up IAM role ARN for the given API key
     */
    getRoleForApiKey(apiKey: string): Promise<string>;
}
//# sourceMappingURL=apiKeyService.d.ts.map