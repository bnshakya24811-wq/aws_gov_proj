"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiKeyService = void 0;
/**
 * Service for API Key to IAM Role mapping lookups
 */
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const logger_1 = require("../utils/logger");
const errorHandler_1 = require("../utils/errorHandler");
class ApiKeyService {
    client;
    tableName;
    logger;
    constructor(region, tableName) {
        const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region });
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
        this.tableName = tableName;
        this.logger = new logger_1.Logger('ApiKeyService');
    }
    /**
     * Look up IAM role ARN for the given API key
     */
    async getRoleForApiKey(apiKey) {
        try {
            this.logger.info('Looking up role for API key', {
                tableName: this.tableName,
            });
            const command = new lib_dynamodb_1.GetCommand({
                TableName: this.tableName,
                Key: { apiKey },
            });
            const response = await this.client.send(command);
            if (!response.Item) {
                this.logger.warn('API key not found in DynamoDB');
                throw new errorHandler_1.LambdaError(403, 'Invalid API key');
            }
            const mapping = response.Item;
            if (!mapping.roleArn) {
                this.logger.error('Role ARN not found in mapping', undefined, {
                    apiKey: apiKey.substring(0, 8) + '...',
                });
                throw new errorHandler_1.LambdaError(500, 'Invalid API key mapping');
            }
            this.logger.info('Successfully retrieved role ARN', {
                userName: mapping.userName,
                permissions: mapping.permissions,
            });
            return mapping.roleArn;
        }
        catch (error) {
            if (error instanceof errorHandler_1.LambdaError) {
                throw error;
            }
            this.logger.error('Error querying DynamoDB', error);
            throw new errorHandler_1.LambdaError(500, 'Failed to lookup API key');
        }
    }
}
exports.ApiKeyService = ApiKeyService;
//# sourceMappingURL=apiKeyService.js.map