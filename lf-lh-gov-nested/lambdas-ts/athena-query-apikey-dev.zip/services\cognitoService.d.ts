export interface AuthenticationResult {
    accessToken: string;
    idToken: string;
    refreshToken?: string;
    expiresIn: number;
}
export interface UserInfo {
    username: string;
    email?: string;
    groups: string[];
    attributes: Record<string, string>;
}
export declare class CognitoService {
    private client;
    private userPoolId;
    private clientId;
    private clientSecret;
    constructor(region: string, userPoolId: string, clientId: string, clientSecret: string);
    /**
     * Authenticate user with username and password
     */
    authenticateUser(username: string, password: string): Promise<AuthenticationResult>;
    /**
     * Get user information from access token
     */
    getUserInfo(accessToken: string): Promise<UserInfo>;
    /**
     * Map Cognito user groups to Lake Formation role ARN
     */
    mapUserToLFRole(userInfo: UserInfo, devRoleArn: string, superRoleArn: string): string;
    /**
     * Calculate SECRET_HASH required for Cognito authentication
     */
    private calculateSecretHash;
}
//# sourceMappingURL=cognitoService.d.ts.map