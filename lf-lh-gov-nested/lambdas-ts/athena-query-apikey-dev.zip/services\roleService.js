"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleService = void 0;
/**
 * Service for IAM role assumption
 */
const client_sts_1 = require("@aws-sdk/client-sts");
const logger_1 = require("../utils/logger");
const errorHandler_1 = require("../utils/errorHandler");
class RoleService {
    client;
    logger;
    constructor(region) {
        this.client = new client_sts_1.STSClient({ region });
        this.logger = new logger_1.Logger('RoleService');
    }
    /**
     * Assume the specified IAM role and return temporary credentials
     */
    async assumeRole(roleArn) {
        try {
            this.logger.info('Assuming IAM role', { roleArn });
            const command = new client_sts_1.AssumeRoleCommand({
                RoleArn: roleArn,
                RoleSessionName: 'athena-query-session',
                DurationSeconds: 3600,
            });
            const response = await this.client.send(command);
            if (!response.Credentials) {
                throw new Error('No credentials returned from AssumeRole');
            }
            const creds = response.Credentials;
            if (!creds.AccessKeyId || !creds.SecretAccessKey || !creds.SessionToken) {
                throw new Error('Incomplete credentials returned');
            }
            this.logger.info('Successfully assumed role');
            return {
                accessKeyId: creds.AccessKeyId,
                secretAccessKey: creds.SecretAccessKey,
                sessionToken: creds.SessionToken,
            };
        }
        catch (error) {
            this.logger.error('Error assuming role', error, { roleArn });
            throw new errorHandler_1.LambdaError(500, `Failed to assume role: ${error.message}`);
        }
    }
}
exports.RoleService = RoleService;
//# sourceMappingURL=roleService.js.map