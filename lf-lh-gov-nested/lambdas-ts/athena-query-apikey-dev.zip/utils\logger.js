"use strict";
/**
 * Logging utility
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = void 0;
class Logger {
    context;
    constructor(context) {
        this.context = context;
    }
    info(message, meta) {
        console.log(JSON.stringify({
            level: 'INFO',
            context: this.context,
            message,
            ...meta,
            timestamp: new Date().toISOString(),
        }));
    }
    error(message, error, meta) {
        console.error(JSON.stringify({
            level: 'ERROR',
            context: this.context,
            message,
            error: error?.message,
            stack: error?.stack,
            ...meta,
            timestamp: new Date().toISOString(),
        }));
    }
    warn(message, meta) {
        console.warn(JSON.stringify({
            level: 'WARN',
            context: this.context,
            message,
            ...meta,
            timestamp: new Date().toISOString(),
        }));
    }
    debug(message, meta) {
        if (process.env.LOG_LEVEL === 'DEBUG') {
            console.log(JSON.stringify({
                level: 'DEBUG',
                context: this.context,
                message,
                ...meta,
                timestamp: new Date().toISOString(),
            }));
        }
    }
}
exports.Logger = Logger;
//# sourceMappingURL=logger.js.map