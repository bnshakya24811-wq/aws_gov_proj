/**
 * Environment configuration
 */
import { EnvironmentConfig } from './types';
export declare const getConfig: () => EnvironmentConfig;
//# sourceMappingURL=config.d.ts.map