/**
 * CloudFormation Custom Resource Handler
 * Processes API key mappings and stores them in Secrets Manager and DynamoDB
 */
import { CustomResourceEvent, CustomResourceContext } from './types-custom-resource';
/**
 * Main handler for CloudFormation custom resource
 */
export declare const handler: (event: CustomResourceEvent, context: CustomResourceContext) => Promise<void>;
//# sourceMappingURL=handler-custom-resource.d.ts.map