/**
 * Lambda handler for Athena queries with Lake Formation permissions.
 * Supports three authentication methods:
 * - API key: Maps API key to IAM role, assumes role, executes query
 * - IAM: Maps IAM user ARN to IAM role, assumes role, executes query
 * - OAuth: Authenticates with Cognito, maps user to IAM role, assumes role, executes query
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
/**
 * Main Lambda handler
 */
export declare const handler: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=index.d.ts.map