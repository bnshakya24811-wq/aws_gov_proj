import { AssumedCredentials } from '../types';
export interface ApiKeyAuthResult {
    roleArn: string;
    userName?: string;
    secretName: string;
    credentials: AssumedCredentials;
}
export interface ApiKeyAuthConfig {
    region: string;
    dynamoTableName: string;
    environment?: string;
    secretKeyPrefix?: string;
}
/**
 * High-level service that orchestrates the complete API key authentication flow:
 * API Key → Secrets Manager → DynamoDB → Role Assumption
 */
export declare class ApiKeyAuthService {
    private secretsService;
    private mappingService;
    private roleService;
    private environment?;
    private secretKeyPrefix;
    private logger;
    constructor(config: ApiKeyAuthConfig);
    /**
     * Complete authentication flow: API key → Role credentials
     *
     * Flow:
     * 1. Find secret containing the API key
     * 2. Get role ARN from DynamoDB using secret name
     * 3. Assume the role
     * 4. Return credentials
     */
    authenticate(apiKey: string): Promise<ApiKeyAuthResult>;
    /**
     * Get only the role ARN without assuming the role
     * Useful if you want to defer role assumption
     */
    getRoleArn(apiKey: string): Promise<string>;
}
//# sourceMappingURL=apiKeyAuthService.d.ts.map