"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiKeyAuthService = void 0;
/**
 * Orchestration service for API Key authentication flow
 * Combines SecretsManagerService + ApiKeyMappingService + RoleService
 * Can be easily plugged into any Lambda that needs API key auth
 */
const secretsManagerService_1 = require("./secretsManagerService");
const apiKeyMappingService_1 = require("./apiKeyMappingService");
const roleService_1 = require("./roleService");
const logger_1 = require("../utils/logger");
const errorHandler_1 = require("../utils/errorHandler");
/**
 * High-level service that orchestrates the complete API key authentication flow:
 * API Key → Secrets Manager → DynamoDB → Role Assumption
 */
class ApiKeyAuthService {
    secretsService;
    mappingService;
    roleService;
    environment;
    secretKeyPrefix;
    logger;
    constructor(config) {
        this.secretsService = new secretsManagerService_1.SecretsManagerService(config.region);
        this.mappingService = new apiKeyMappingService_1.ApiKeyMappingService(config.region, config.dynamoTableName);
        this.roleService = new roleService_1.RoleService(config.region);
        this.environment = config.environment;
        this.secretKeyPrefix = config.secretKeyPrefix || 'lf-apikey-';
        this.logger = new logger_1.Logger('ApiKeyAuthService');
    }
    /**
     * Complete authentication flow: API key → Role credentials
     *
     * Flow:
     * 1. Find secret containing the API key
     * 2. Get role ARN from DynamoDB using secret name
     * 3. Assume the role
     * 4. Return credentials
     */
    async authenticate(apiKey) {
        try {
            this.logger.info('Starting API key authentication flow');
            // Step 1: Find secret by API key value
            const secretMatch = await this.secretsService.findSecretByApiKey(apiKey, this.secretKeyPrefix, this.environment);
            if (!secretMatch) {
                throw new errorHandler_1.LambdaError(403, 'Invalid API key');
            }
            const { secretName, secretValue } = secretMatch;
            const userName = secretValue.userName || 'unknown';
            this.logger.info(`Found matching secret: ${secretName}, user: ${userName}`);
            // Step 2: Get role mapping from DynamoDB
            const mapping = await this.mappingService.getRoleBySecretName(secretName);
            // Step 3: Assume the role
            const credentials = await this.roleService.assumeRole(mapping.roleArn, userName);
            this.logger.info('API key authentication successful', {
                userName,
                roleArn: mapping.roleArn,
            });
            return {
                roleArn: mapping.roleArn,
                userName,
                secretName,
                credentials,
            };
        }
        catch (error) {
            if (error instanceof errorHandler_1.LambdaError) {
                throw error;
            }
            this.logger.error('API key authentication failed', error);
            throw new errorHandler_1.LambdaError(500, 'Authentication failed');
        }
    }
    /**
     * Get only the role ARN without assuming the role
     * Useful if you want to defer role assumption
     */
    async getRoleArn(apiKey) {
        const secretMatch = await this.secretsService.findSecretByApiKey(apiKey, this.secretKeyPrefix, this.environment);
        if (!secretMatch) {
            throw new errorHandler_1.LambdaError(403, 'Invalid API key');
        }
        const mapping = await this.mappingService.getRoleBySecretName(secretMatch.secretName);
        return mapping.roleArn;
    }
}
exports.ApiKeyAuthService = ApiKeyAuthService;
//# sourceMappingURL=apiKeyAuthService.js.map