export interface RoleMapping {
    secretName: string;
    roleArn: string;
    userName?: string;
    secretArn?: string;
    permissions?: string;
}
export declare class ApiKeyMappingService {
    private client;
    private tableName;
    private logger;
    constructor(region: string, tableName: string);
    /**
     * Get role ARN from DynamoDB using secret name as key
     */
    getRoleBySecretName(secretName: string): Promise<RoleMapping>;
    /**
     * Get role ARN only (convenience method)
     */
    getRoleArn(secretName: string): Promise<string>;
}
//# sourceMappingURL=apiKeyMappingService.d.ts.map