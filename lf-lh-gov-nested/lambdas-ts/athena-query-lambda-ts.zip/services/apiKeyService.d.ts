export declare class ApiKeyService {
    private secretsClient;
    private dynamoClient;
    private tableName;
    private environment;
    private logger;
    constructor(region: string, tableName: string, environment: string);
    /**
     * Look up IAM role ARN for the given API key
     * Flow:
     * 1. List Secrets Manager with 'lf-apikey-*' pattern and LFAPIKeyType tag
     * 2. Scan each secret to find matching API key value
     * 3. Use matched secretName to query DynamoDB
     * 4. Return roleArn from DynamoDB mapping
     */
    getRoleForApiKey(apiKey: string): Promise<string>;
}
//# sourceMappingURL=apiKeyService.d.ts.map