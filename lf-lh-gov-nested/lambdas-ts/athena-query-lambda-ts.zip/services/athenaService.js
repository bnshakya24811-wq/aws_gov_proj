"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AthenaService = void 0;
/**
 * Service for Athena query execution with Lake Formation permissions
 */
const client_athena_1 = require("@aws-sdk/client-athena");
const logger_1 = require("../utils/logger");
const errorHandler_1 = require("../utils/errorHandler");
class AthenaService {
    logger;
    region;
    databaseName;
    outputLocation;
    constructor(region, databaseName, outputLocation) {
        this.region = region;
        this.databaseName = databaseName;
        this.outputLocation = outputLocation;
        this.logger = new logger_1.Logger('AthenaService');
    }
    /**
     * Create Athena client with assumed credentials
     */
    getClient(credentials) {
        return new client_athena_1.AthenaClient({
            region: this.region,
            credentials: {
                accessKeyId: credentials.accessKeyId,
                secretAccessKey: credentials.secretAccessKey,
                sessionToken: credentials.sessionToken,
            },
        });
    }
    /**
     * Build SQL query string
     */
    buildQuery(tableName, limit) {
        // Wrap database and table names in double quotes to handle hyphens
        return `SELECT * FROM "${this.databaseName}"."${tableName}" LIMIT ${limit}`;
    }
    /**
     * Start an Athena query execution
     */
    async startQuery(tableName, limit, credentials) {
        try {
            const query = this.buildQuery(tableName, limit);
            this.logger.info('Starting Athena query', { query });
            const client = this.getClient(credentials);
            const command = new client_athena_1.StartQueryExecutionCommand({
                QueryString: query,
                QueryExecutionContext: {
                    Database: this.databaseName,
                },
                ResultConfiguration: {
                    OutputLocation: this.outputLocation,
                },
                WorkGroup: 'primary',
            });
            const response = await client.send(command);
            if (!response.QueryExecutionId) {
                throw new Error('No QueryExecutionId returned');
            }
            this.logger.info('Query started successfully', {
                queryExecutionId: response.QueryExecutionId,
            });
            return response.QueryExecutionId;
        }
        catch (error) {
            this.logger.error('Error starting Athena query', error);
            throw new errorHandler_1.LambdaError(500, `Failed to start query: ${error.message}`);
        }
    }
    /**
     * Wait for query to complete
     */
    async waitForQueryCompletion(queryExecutionId, credentials, maxWaitSeconds = 60) {
        try {
            this.logger.info('Waiting for query completion', { queryExecutionId });
            const client = this.getClient(credentials);
            const startTime = Date.now();
            while (true) {
                const command = new client_athena_1.GetQueryExecutionCommand({ QueryExecutionId: queryExecutionId });
                const response = await client.send(command);
                const status = response.QueryExecution?.Status?.State;
                if (!status) {
                    throw new Error('No query status returned');
                }
                this.logger.debug('Query status', { status, queryExecutionId });
                if (status === client_athena_1.QueryExecutionState.SUCCEEDED ||
                    status === client_athena_1.QueryExecutionState.FAILED ||
                    status === client_athena_1.QueryExecutionState.CANCELLED) {
                    this.logger.info('Query completed', { status, queryExecutionId });
                    return status;
                }
                const elapsedSeconds = (Date.now() - startTime) / 1000;
                if (elapsedSeconds > maxWaitSeconds) {
                    this.logger.warn('Query timeout', { queryExecutionId, elapsedSeconds });
                    throw new errorHandler_1.LambdaError(500, 'Query execution timeout');
                }
                // Wait 1 second before next poll
                await new Promise((resolve) => setTimeout(resolve, 1000));
            }
        }
        catch (error) {
            if (error instanceof errorHandler_1.LambdaError) {
                throw error;
            }
            this.logger.error('Error waiting for query', error);
            throw new errorHandler_1.LambdaError(500, `Query execution failed: ${error.message}`);
        }
    }
    /**
     * Get query results
     */
    async getQueryResults(queryExecutionId, credentials) {
        try {
            this.logger.info('Retrieving query results', { queryExecutionId });
            const client = this.getClient(credentials);
            const results = [];
            let nextToken;
            do {
                const command = new client_athena_1.GetQueryResultsCommand({
                    QueryExecutionId: queryExecutionId,
                    NextToken: nextToken,
                });
                const response = await client.send(command);
                // Extract rows
                if (response.ResultSet?.Rows) {
                    for (const row of response.ResultSet.Rows) {
                        const rowData = row.Data?.map((field) => field.VarCharValue || '') || [];
                        results.push(rowData);
                    }
                }
                nextToken = response.NextToken;
            } while (nextToken);
            this.logger.info('Retrieved query results', {
                rowCount: results.length,
                queryExecutionId,
            });
            return results;
        }
        catch (error) {
            this.logger.error('Error getting query results', error);
            throw new errorHandler_1.LambdaError(500, `Failed to retrieve results: ${error.message}`);
        }
    }
    /**
     * Execute complete query workflow
     */
    async executeQuery(tableName, limit, credentials) {
        const queryExecutionId = await this.startQuery(tableName, limit, credentials);
        const status = await this.waitForQueryCompletion(queryExecutionId, credentials);
        if (status !== client_athena_1.QueryExecutionState.SUCCEEDED) {
            throw new errorHandler_1.LambdaError(500, `Query failed with status: ${status}`);
        }
        const results = await this.getQueryResults(queryExecutionId, credentials);
        const query = this.buildQuery(tableName, limit);
        return { query, results };
    }
    /**
     * Execute raw SQL query (for OAuth)
     */
    async executeRawQuery(sqlQuery, credentials) {
        try {
            this.logger.info('Starting raw SQL query', { query: sqlQuery });
            const client = this.getClient(credentials);
            const command = new client_athena_1.StartQueryExecutionCommand({
                QueryString: sqlQuery,
                QueryExecutionContext: {
                    Database: this.databaseName,
                },
                ResultConfiguration: {
                    OutputLocation: this.outputLocation,
                },
                WorkGroup: 'primary',
            });
            const response = await client.send(command);
            if (!response.QueryExecutionId) {
                throw new Error('No QueryExecutionId returned');
            }
            const queryExecutionId = response.QueryExecutionId;
            this.logger.info('Raw query started successfully', { queryExecutionId });
            const status = await this.waitForQueryCompletion(queryExecutionId, credentials);
            if (status !== client_athena_1.QueryExecutionState.SUCCEEDED) {
                throw new errorHandler_1.LambdaError(500, `Query failed with status: ${status}`);
            }
            const results = await this.getQueryResults(queryExecutionId, credentials);
            return { query: sqlQuery, results };
        }
        catch (error) {
            if (error instanceof errorHandler_1.LambdaError) {
                throw error;
            }
            this.logger.error('Error executing raw query', error);
            throw new errorHandler_1.LambdaError(500, `Failed to execute query: ${error.message}`);
        }
    }
}
exports.AthenaService = AthenaService;
//# sourceMappingURL=athenaService.js.map