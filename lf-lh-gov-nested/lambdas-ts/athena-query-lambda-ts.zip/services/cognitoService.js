"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CognitoService = void 0;
/**
 * Cognito Service - Handles OAuth 2.0 authentication with AWS Cognito
 */
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const crypto_1 = require("crypto");
const logger_1 = require("../utils/logger");
const errorHandler_1 = require("../utils/errorHandler");
const logger = new logger_1.Logger('CognitoService');
class CognitoService {
    client;
    userPoolId;
    clientId;
    clientSecret;
    constructor(region, userPoolId, clientId, clientSecret) {
        this.client = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({ region });
        this.userPoolId = userPoolId;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }
    /**
     * Authenticate user with username and password
     */
    async authenticateUser(username, password) {
        try {
            const secretHash = this.calculateSecretHash(username);
            const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
                ClientId: this.clientId,
                AuthFlow: client_cognito_identity_provider_1.AuthFlowType.USER_PASSWORD_AUTH,
                AuthParameters: {
                    USERNAME: username,
                    PASSWORD: password,
                    SECRET_HASH: secretHash,
                },
            });
            const response = await this.client.send(command);
            if (!response.AuthenticationResult) {
                throw new errorHandler_1.LambdaError(401, 'Authentication failed');
            }
            const authResult = response.AuthenticationResult;
            logger.info('User authenticated successfully', { username });
            return {
                accessToken: authResult.AccessToken,
                idToken: authResult.IdToken,
                refreshToken: authResult.RefreshToken,
                expiresIn: authResult.ExpiresIn,
            };
        }
        catch (error) {
            if (error.name === 'NotAuthorizedException') {
                logger.warn('Authentication failed - invalid credentials', { username });
                throw new errorHandler_1.LambdaError(401, 'Invalid username or password');
            }
            logger.error('Cognito authentication error', error);
            throw new errorHandler_1.LambdaError(500, `Authentication error: ${error.message}`);
        }
    }
    /**
     * Get user information from access token
     */
    async getUserInfo(accessToken) {
        try {
            // Get user details
            const getUserCommand = new client_cognito_identity_provider_1.GetUserCommand({
                AccessToken: accessToken,
            });
            const userResponse = await this.client.send(getUserCommand);
            const username = userResponse.Username;
            const attributes = {};
            // Parse user attributes
            if (userResponse.UserAttributes) {
                for (const attr of userResponse.UserAttributes) {
                    if (attr.Name && attr.Value) {
                        attributes[attr.Name] = attr.Value;
                    }
                }
            }
            // Get user groups
            let groups = [];
            try {
                const groupsCommand = new client_cognito_identity_provider_1.AdminListGroupsForUserCommand({
                    Username: username,
                    UserPoolId: this.userPoolId,
                });
                const groupsResponse = await this.client.send(groupsCommand);
                groups = groupsResponse.Groups?.map((g) => g.GroupName) || [];
            }
            catch (error) {
                logger.warn('Could not retrieve user groups', {
                    username,
                    error: error.message,
                });
            }
            logger.info('Retrieved user info', { username, groups });
            return {
                username,
                email: attributes['email'],
                groups,
                attributes,
            };
        }
        catch (error) {
            logger.error('Failed to get user info', error);
            throw new errorHandler_1.LambdaError(500, `Failed to retrieve user information: ${error.message}`);
        }
    }
    /**
     * Map Cognito user groups to Lake Formation role ARN
     */
    mapUserToLFRole(userInfo, devRoleArn, superRoleArn) {
        const { groups } = userInfo;
        // Admin or Admins group → Super User role
        if (groups.includes('Admins') || groups.includes('Admin')) {
            logger.info('Mapping user to Super User role', {
                username: userInfo.username,
                group: 'Admins',
            });
            return superRoleArn;
        }
        // All other groups (Developers, Analysts, DataScientists) → Dev User role
        logger.info('Mapping user to Dev User role', {
            username: userInfo.username,
            groups,
        });
        return devRoleArn;
    }
    /**
     * Calculate SECRET_HASH required for Cognito authentication
     */
    calculateSecretHash(username) {
        const message = username + this.clientId;
        const hmac = (0, crypto_1.createHmac)('sha256', this.clientSecret);
        hmac.update(message);
        return hmac.digest('base64');
    }
}
exports.CognitoService = CognitoService;
//# sourceMappingURL=cognitoService.js.map