import { AssumedCredentials } from '../types';
export declare class RoleService {
    private client;
    private logger;
    constructor(region: string);
    /**
     * Assume the specified IAM role and return temporary credentials
     */
    assumeRole(roleArn: string, sessionName?: string, durationSeconds?: number): Promise<AssumedCredentials>;
}
//# sourceMappingURL=roleService.d.ts.map