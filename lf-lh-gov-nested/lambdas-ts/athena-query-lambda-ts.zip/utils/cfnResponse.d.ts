import { CustomResourceEvent, CustomResourceStatus, CustomResourceContext } from '../types-custom-resource';
/**
 * Send response to CloudFormation
 */
export declare function sendResponse(event: CustomResourceEvent, context: CustomResourceContext, status: CustomResourceStatus, data?: Record<string, any>, physicalResourceId?: string, reason?: string): Promise<void>;
/**
 * Send success response
 */
export declare function sendSuccess(event: CustomResourceEvent, context: CustomResourceContext, data?: Record<string, any>, physicalResourceId?: string): Promise<void>;
/**
 * Send failure response
 */
export declare function sendFailure(event: CustomResourceEvent, context: CustomResourceContext, error: Error | string, physicalResourceId?: string): Promise<void>;
//# sourceMappingURL=cfnResponse.d.ts.map