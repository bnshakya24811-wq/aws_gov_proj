"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiKeyMappingService = void 0;
/**
 * Service for API Key to Role mapping in DynamoDB
 * Reusable module for looking up role ARNs from secret names or API keys
 */
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const logger_1 = require("../utils/logger");
const errorHandler_1 = require("../utils/errorHandler");
class ApiKeyMappingService {
    client;
    tableName;
    logger;
    constructor(region, tableName) {
        this.client = new client_dynamodb_1.DynamoDBClient({ region });
        this.tableName = tableName;
        this.logger = new logger_1.Logger('ApiKeyMappingService');
    }
    /**
     * Get role ARN from DynamoDB using secret name as key
     */
    async getRoleBySecretName(secretName) {
        try {
            this.logger.info(`Looking up role mapping for secret: ${secretName}`);
            const command = new client_dynamodb_1.GetItemCommand({
                TableName: this.tableName,
                Key: { secretName: { S: secretName } },
            });
            const response = await this.client.send(command);
            if (!response.Item) {
                this.logger.error(`No mapping found for secret: ${secretName}`);
                throw new errorHandler_1.LambdaError(500, 'Configuration error: missing role mapping');
            }
            const mapping = {
                secretName,
                roleArn: response.Item.roleArn?.S || '',
                userName: response.Item.userName?.S,
                secretArn: response.Item.secretArn?.S,
                permissions: response.Item.permissions?.S,
            };
            if (!mapping.roleArn) {
                this.logger.error('Role ARN not found in mapping');
                throw new errorHandler_1.LambdaError(500, 'Invalid role mapping: missing roleArn');
            }
            this.logger.info('Successfully retrieved role mapping', {
                userName: mapping.userName,
                roleArn: mapping.roleArn,
            });
            return mapping;
        }
        catch (error) {
            if (error instanceof errorHandler_1.LambdaError) {
                throw error;
            }
            this.logger.error('Error querying DynamoDB', error);
            throw new errorHandler_1.LambdaError(500, 'Failed to lookup role mapping');
        }
    }
    /**
     * Get role ARN only (convenience method)
     */
    async getRoleArn(secretName) {
        const mapping = await this.getRoleBySecretName(secretName);
        return mapping.roleArn;
    }
}
exports.ApiKeyMappingService = ApiKeyMappingService;
//# sourceMappingURL=apiKeyMappingService.js.map