/**
 * Service for Athena query execution with Lake Formation permissions
 */
import { QueryExecutionState } from '@aws-sdk/client-athena';
import { AssumedCredentials } from '../types';
export declare class AthenaService {
    private logger;
    private region;
    private databaseName;
    private outputLocation;
    constructor(region: string, databaseName: string, outputLocation: string);
    /**
     * Create Athena client with assumed credentials
     */
    private getClient;
    /**
     * Build SQL query string
     */
    private buildQuery;
    /**
     * Start an Athena query execution
     */
    startQuery(tableName: string, limit: number, credentials: AssumedCredentials): Promise<string>;
    /**
     * Wait for query to complete
     */
    waitForQueryCompletion(queryExecutionId: string, credentials: AssumedCredentials, maxWaitSeconds?: number): Promise<QueryExecutionState>;
    /**
     * Get query results
     */
    getQueryResults(queryExecutionId: string, credentials: AssumedCredentials): Promise<string[][]>;
    /**
     * Execute complete query workflow
     */
    executeQuery(tableName: string, limit: number, credentials: AssumedCredentials): Promise<{
        query: string;
        results: string[][];
    }>;
    /**
     * Execute raw SQL query (for OAuth)
     */
    executeRawQuery(sqlQuery: string, credentials: AssumedCredentials): Promise<{
        query: string;
        results: string[][];
    }>;
}
//# sourceMappingURL=athenaService.d.ts.map