import { APIKeyMapping } from '../types-custom-resource';
export declare class CustomResourceService {
    private apiGateway;
    private secretsManager;
    private dynamodb;
    constructor(region?: string);
    /**
     * Process API key mappings (Create/Update)
     */
    processAPIKeyMappings(mappings: APIKeyMapping[], tableName: string, environment: string): Promise<Record<string, any>>;
    /**
     * Process a single API key mapping
     */
    private processMapping;
    /**
     * Get API key value from API Gateway
     */
    private getAPIKeyValue;
    /**
     * Store secret in Secrets Manager (create or update)
     */
    private storeSecret;
    /**
     * Store mapping in DynamoDB
     */
    private storeDynamoDBMapping;
    /**
     * Cleanup secrets on stack deletion
     */
    deleteSecrets(mappings: APIKeyMapping[]): Promise<void>;
}
//# sourceMappingURL=customResourceService.d.ts.map