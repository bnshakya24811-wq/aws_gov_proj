export declare class IAMUserService {
    private static readonly IAM_USER_TO_ROLE_MAP;
    /**
     * Get Lake Formation role ARN for an IAM user ARN
     */
    getRoleForIAMUser(userArn: string): string;
}
//# sourceMappingURL=iamUserService.d.ts.map