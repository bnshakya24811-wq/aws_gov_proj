/**
 * Service for Secrets Manager operations
 * Reusable module for scanning and retrieving secrets by pattern/value
 */
import { SecretListEntry } from '@aws-sdk/client-secrets-manager';
export interface SecretMatchResult {
    secretName: string;
    secretValue: any;
    metadata?: SecretListEntry;
}
export interface SecretScanOptions {
    namePrefix?: string;
    tagFilters?: {
        key: string;
        value?: string;
    }[];
    maxResults?: number;
    environmentSuffix?: string;
}
export declare class SecretsManagerService {
    private client;
    private logger;
    constructor(region: string);
    /**
     * List secrets matching the given criteria
     */
    listSecrets(options: SecretScanOptions): Promise<SecretListEntry[]>;
    /**
     * Get the value of a specific secret
     */
    getSecretValue<T = any>(secretName: string): Promise<T>;
    /**
     * Scan secrets to find one matching a specific field value
     * Generic method that can search for any field match
     */
    findSecretByFieldValue<T = any>(scanOptions: SecretScanOptions, fieldName: keyof T, fieldValue: any): Promise<SecretMatchResult | null>;
    /**
     * Convenience method: Find secret by API key value
     */
    findSecretByApiKey(apiKey: string, namePrefix?: string, environment?: string): Promise<SecretMatchResult | null>;
}
//# sourceMappingURL=secretsManagerService.d.ts.map