"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecretsManagerService = void 0;
/**
 * Service for Secrets Manager operations
 * Reusable module for scanning and retrieving secrets by pattern/value
 */
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const logger_1 = require("../utils/logger");
const errorHandler_1 = require("../utils/errorHandler");
class SecretsManagerService {
    client;
    logger;
    constructor(region) {
        this.client = new client_secrets_manager_1.SecretsManagerClient({ region });
        this.logger = new logger_1.Logger('SecretsManagerService');
    }
    /**
     * List secrets matching the given criteria
     */
    async listSecrets(options) {
        const filters = [];
        if (options.namePrefix) {
            filters.push({ Key: 'name', Values: [options.namePrefix] });
        }
        if (options.tagFilters) {
            options.tagFilters.forEach(tag => {
                if (tag.value) {
                    filters.push({ Key: 'tag-value', Values: [tag.value] });
                }
                else {
                    filters.push({ Key: 'tag-key', Values: [tag.key] });
                }
            });
        }
        const command = new client_secrets_manager_1.ListSecretsCommand({
            Filters: filters.length > 0 ? filters : undefined,
            MaxResults: options.maxResults || 20,
        });
        this.logger.info('Listing secrets', { filters, maxResults: options.maxResults });
        const response = await this.client.send(command);
        return response.SecretList || [];
    }
    /**
     * Get the value of a specific secret
     */
    async getSecretValue(secretName) {
        try {
            const command = new client_secrets_manager_1.GetSecretValueCommand({ SecretId: secretName });
            const response = await this.client.send(command);
            if (!response.SecretString) {
                throw new errorHandler_1.LambdaError(500, `Secret ${secretName} has no string value`);
            }
            return JSON.parse(response.SecretString);
        }
        catch (error) {
            this.logger.error(`Error retrieving secret ${secretName}`, error);
            throw error;
        }
    }
    /**
     * Scan secrets to find one matching a specific field value
     * Generic method that can search for any field match
     */
    async findSecretByFieldValue(scanOptions, fieldName, fieldValue) {
        const secrets = await this.listSecrets(scanOptions);
        this.logger.info(`Scanning ${secrets.length} secrets for matching ${String(fieldName)}`);
        for (const secretMetadata of secrets) {
            const secretName = secretMetadata.Name;
            if (!secretName)
                continue;
            // Filter by environment suffix if specified
            if (scanOptions.environmentSuffix && !secretName.endsWith(scanOptions.environmentSuffix)) {
                this.logger.debug(`Skipping secret (environment mismatch): ${secretName}`);
                continue;
            }
            try {
                const secretValue = await this.getSecretValue(secretName);
                // Check if field matches
                if (secretValue[fieldName] === fieldValue) {
                    this.logger.info(`Found matching secret: ${secretName}`);
                    return {
                        secretName,
                        secretValue,
                        metadata: secretMetadata,
                    };
                }
            }
            catch (error) {
                this.logger.warn(`Error reading secret ${secretName}`, {
                    error: error.message
                });
                continue;
            }
        }
        this.logger.warn('No matching secret found');
        return null;
    }
    /**
     * Convenience method: Find secret by API key value
     */
    async findSecretByApiKey(apiKey, namePrefix = 'lf-apikey-', environment) {
        return this.findSecretByFieldValue({
            namePrefix,
            tagFilters: [{ key: 'LFAPIKeyType' }],
            environmentSuffix: environment ? `-${environment}` : undefined,
        }, 'apiKey', apiKey);
    }
}
exports.SecretsManagerService = SecretsManagerService;
//# sourceMappingURL=secretsManagerService.js.map