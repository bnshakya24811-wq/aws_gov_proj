"use strict";
/**
 * Type definitions for CloudFormation Custom Resource
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomResourceStatus = void 0;
var CustomResourceStatus;
(function (CustomResourceStatus) {
    CustomResourceStatus["SUCCESS"] = "SUCCESS";
    CustomResourceStatus["FAILED"] = "FAILED";
})(CustomResourceStatus || (exports.CustomResourceStatus = CustomResourceStatus = {}));
//# sourceMappingURL=types-custom-resource.js.map