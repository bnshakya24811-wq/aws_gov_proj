"use strict";
/**
 * Type definitions for Lambda handler
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryStatus = void 0;
var QueryStatus;
(function (QueryStatus) {
    QueryStatus["QUEUED"] = "QUEUED";
    QueryStatus["RUNNING"] = "RUNNING";
    QueryStatus["SUCCEEDED"] = "SUCCEEDED";
    QueryStatus["FAILED"] = "FAILED";
    QueryStatus["CANCELLED"] = "CANCELLED";
})(QueryStatus || (exports.QueryStatus = QueryStatus = {}));
//# sourceMappingURL=types.js.map