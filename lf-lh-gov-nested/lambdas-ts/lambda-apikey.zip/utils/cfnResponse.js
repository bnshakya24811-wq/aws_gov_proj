"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendResponse = sendResponse;
exports.sendSuccess = sendSuccess;
exports.sendFailure = sendFailure;
/**
 * CloudFormation Custom Resource Response Utility
 * Handles sending responses back to CloudFormation via pre-signed S3 URL
 */
const https_1 = __importDefault(require("https"));
const url_1 = __importDefault(require("url"));
const types_custom_resource_1 = require("../types-custom-resource");
const logger_1 = require("./logger");
const logger = new logger_1.Logger('CFNResponse');
/**
 * Send response to CloudFormation
 */
async function sendResponse(event, context, status, data, physicalResourceId, reason) {
    const responseBody = {
        Status: status,
        Reason: reason || `See CloudWatch Log Stream: ${context.logStreamName}`,
        PhysicalResourceId: physicalResourceId || context.awsRequestId,
        StackId: event.StackId,
        RequestId: event.RequestId,
        LogicalResourceId: event.LogicalResourceId,
        Data: data,
    };
    logger.info('Sending CloudFormation response', {
        status,
        physicalResourceId: responseBody.PhysicalResourceId,
        data,
    });
    const responseBodyStr = JSON.stringify(responseBody);
    const parsedUrl = url_1.default.parse(event.ResponseURL);
    const options = {
        hostname: parsedUrl.hostname,
        port: 443,
        path: parsedUrl.path,
        method: 'PUT',
        headers: {
            'Content-Type': '',
            'Content-Length': responseBodyStr.length,
        },
    };
    return new Promise((resolve, reject) => {
        const request = https_1.default.request(options, (response) => {
            logger.info('CloudFormation response sent', {
                statusCode: response.statusCode,
                statusMessage: response.statusMessage,
            });
            resolve();
        });
        request.on('error', (error) => {
            logger.error('Failed to send CloudFormation response', error);
            reject(error);
        });
        request.write(responseBodyStr);
        request.end();
    });
}
/**
 * Send success response
 */
async function sendSuccess(event, context, data, physicalResourceId) {
    return sendResponse(event, context, types_custom_resource_1.CustomResourceStatus.SUCCESS, data, physicalResourceId);
}
/**
 * Send failure response
 */
async function sendFailure(event, context, error, physicalResourceId) {
    const errorMessage = error instanceof Error ? error.message : error;
    return sendResponse(event, context, types_custom_resource_1.CustomResourceStatus.FAILED, { Error: errorMessage }, physicalResourceId, errorMessage);
}
//# sourceMappingURL=cfnResponse.js.map