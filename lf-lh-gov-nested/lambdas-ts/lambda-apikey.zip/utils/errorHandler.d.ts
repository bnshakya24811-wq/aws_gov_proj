/**
 * Error handling utilities
 */
import { APIGatewayProxyResult } from 'aws-lambda';
export declare const createErrorResponse: (statusCode: number, message: string) => APIGatewayProxyResult;
export declare const createSuccessResponse: (data: unknown) => APIGatewayProxyResult;
export declare class LambdaError extends Error {
    statusCode: number;
    constructor(statusCode: number, message: string);
}
//# sourceMappingURL=errorHandler.d.ts.map