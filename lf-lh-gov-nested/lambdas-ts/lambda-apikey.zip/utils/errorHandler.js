"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LambdaError = exports.createSuccessResponse = exports.createErrorResponse = void 0;
const createErrorResponse = (statusCode, message) => {
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
            success: false,
            error: message,
        }),
    };
};
exports.createErrorResponse = createErrorResponse;
const createSuccessResponse = (data) => {
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify(data),
    };
};
exports.createSuccessResponse = createSuccessResponse;
class LambdaError extends Error {
    statusCode;
    constructor(statusCode, message) {
        super(message);
        this.statusCode = statusCode;
        this.name = 'LambdaError';
    }
}
exports.LambdaError = LambdaError;
//# sourceMappingURL=errorHandler.js.map